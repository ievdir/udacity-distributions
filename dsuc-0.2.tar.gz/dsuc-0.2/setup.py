from setuptools import setup

setup(name='dsuc',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['dsuc'],
      author = 'Ieva Dirdaite',
      author_email = 'ieva.dirdaite@gmail.com',
      zip_safe=False)
